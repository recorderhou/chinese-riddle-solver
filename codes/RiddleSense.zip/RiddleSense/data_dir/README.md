# Download the dataset files.
Please read and submit the form [***here***](https://forms.gle/iWdsgN44TeoXW19e6) to get the link for downloading our data. You can unzip the dataset files here after you get the data.

# Submission to evaluate on the test set
To evaluate your models on the test set, please follow our guide [***here***](https://inklab.usc.edu//RiddleSense/#submission-guide).

# Citation

Please cite the CommonsenseQA paper in addition to our paper if you use their data as additional training data.