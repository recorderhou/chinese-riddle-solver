---
license: mit
thumbnail: https://huggingface.co/front/thumbnails/facebook.png
pipeline_tag: zero-shot-classification
widget:
- text: "Last week I upgraded my iOS version and ever since then my phone has been overheating whenever I use your app."
  labels: "mobile, website, billing, account access"
---
