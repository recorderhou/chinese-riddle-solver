---
language: de
license: apache-2.0
---
## distilbert-base-german-cased
